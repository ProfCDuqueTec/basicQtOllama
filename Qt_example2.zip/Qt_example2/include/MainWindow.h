#pragma once

#include <QMainWindow>
#include <QLabel>
#include <QPushButton>
#include <QLineEdit>
#include <QTextEdit>

class QNetworkAccessManager;
class QNetworkReply;

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow() override;

private slots:
    void on_buttonClicked();
    void on_ollamaReplyFinished(QNetworkReply *reply);

private:
    void sendPromptToOllama(const QString &prompt);
    void setWaitingState(bool waiting);

    QLabel      *label_;
    QPushButton *button_;
    QLineEdit   *lineEdit_;
    QLineEdit   *modelLineEdit_;
    QTextEdit   *textEdit_;

    QNetworkAccessManager *networkManager_;
};
