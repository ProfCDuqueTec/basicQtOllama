#include "MainWindow.h"

#include <QAction>
#include <QHBoxLayout>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonParseError>
#include <QMenu>
#include <QMenuBar>
#include <QMessageBox>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QNetworkRequest>
#include <QStatusBar>
#include <QToolBar>
#include <QUrl>
#include <QVBoxLayout>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent),
      label_(new QLabel("Asistente IA local con Ollama", this)),
      button_(new QPushButton("Enviar a Ollama", this)),
      lineEdit_(new QLineEdit(this)),
      modelLineEdit_(new QLineEdit("llama3.2", this)),
      textEdit_(new QTextEdit(this)),
      networkManager_(new QNetworkAccessManager(this))
{
    // 1) Configurar la ventana principal
    setWindowTitle("Ejemplo Qt + Ollama – Proyecto Integrador");
    resize(720, 480);

    // 2) Barra de menú con acción "Salir"
    QMenu *fileMenu = menuBar()->addMenu("&Archivo");
    QAction *exitAction = fileMenu->addAction("Salir");
    connect(exitAction, &QAction::triggered, this, &QMainWindow::close);

    // 3) Barra de estado
    statusBar()->showMessage("Listo. Verifica que Ollama esté activo en http://127.0.0.1:11434");

    // 4) Barra de herramientas que reutiliza la acción "Salir"
    QToolBar *toolbar = addToolBar("Principal");
    toolbar->addAction(exitAction);

    // 5) Conectar acciones de envío
    connect(button_, &QPushButton::clicked, this, &MainWindow::on_buttonClicked);
    connect(lineEdit_, &QLineEdit::returnPressed, this, &MainWindow::on_buttonClicked);

    // 6) Crear un widget central con layout
    QWidget *central = new QWidget(this);
    setCentralWidget(central);

    QVBoxLayout *vbox = new QVBoxLayout;
    vbox->addWidget(label_);

    // Selector mínimo de modelo
    QHBoxLayout *modelBox = new QHBoxLayout;
    modelBox->addWidget(new QLabel("Modelo:", this));
    modelLineEdit_->setPlaceholderText("Ejemplo: llama3.2");
    modelBox->addWidget(modelLineEdit_);
    vbox->addLayout(modelBox);

    // Entrada de prompt + botón
    QHBoxLayout *hbox = new QHBoxLayout;
    hbox->addWidget(new QLabel("Comando / prompt:", this));
    lineEdit_->setPlaceholderText("Escribe un comando para la IA...");
    hbox->addWidget(lineEdit_);
    hbox->addWidget(button_);
    vbox->addLayout(hbox);

    // Área de conversación
    vbox->addWidget(new QLabel("Conversación:", this));
    textEdit_->setReadOnly(true);
    textEdit_->append("Sistema: escribe un prompt y presiona Enter o el botón.\n");
    vbox->addWidget(textEdit_);

    central->setLayout(vbox);
}

MainWindow::~MainWindow()
{
    // Qt libera automáticamente los objetos hijos gracias al parent-child ownership.
}

void MainWindow::on_buttonClicked()
{
    const QString input = lineEdit_->text().trimmed();

    if (input.isEmpty()) {
        QMessageBox::warning(this, "Advertencia", "El campo de prompt está vacío.");
        return;
    }

    label_->setText(QStringLiteral("Último prompt enviado a Ollama"));
    textEdit_->append(QStringLiteral("Tú:\n") + input + QStringLiteral("\n"));
    lineEdit_->clear();

    sendPromptToOllama(input);
}

void MainWindow::sendPromptToOllama(const QString &prompt)
{
    setWaitingState(true);
    statusBar()->showMessage("Enviando prompt a Ollama...");

    QString model = modelLineEdit_->text().trimmed();
    if (model.isEmpty()) {
        model = QStringLiteral("llama3.2");
        modelLineEdit_->setText(model);
    }

    QNetworkRequest request{QUrl("http://127.0.0.1:11434/api/generate")};
    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");

    QJsonObject body;
    body["model"] = model;
    body["prompt"] = prompt;
    body["stream"] = false; // Facilita el parseo para alumnos: una sola respuesta JSON.

    const QByteArray jsonData = QJsonDocument(body).toJson(QJsonDocument::Compact);

    QNetworkReply *reply = networkManager_->post(request, jsonData);
    connect(reply, &QNetworkReply::finished, this, [this, reply]() {
        on_ollamaReplyFinished(reply);
    });
}

void MainWindow::on_ollamaReplyFinished(QNetworkReply *reply)
{
    const QByteArray rawData = reply->readAll();
    const int httpStatus = reply->attribute(QNetworkRequest::HttpStatusCodeAttribute).toInt();

    if (reply->error() != QNetworkReply::NoError) {
        QString detail = reply->errorString();

        // Ollama suele devolver detalles adicionales en JSON cuando el modelo no existe.
        QJsonParseError parseError;
        const QJsonDocument errorDoc = QJsonDocument::fromJson(rawData, &parseError);
        if (parseError.error == QJsonParseError::NoError && errorDoc.isObject()) {
            const QString apiError = errorDoc.object().value("error").toString();
            if (!apiError.isEmpty()) {
                detail += QStringLiteral("\nDetalle Ollama: ") + apiError;
            }
        }

        textEdit_->append(QStringLiteral("Error:\nNo se pudo obtener respuesta de Ollama."
                                      "\nHTTP: ") + QString::number(httpStatus) +
                          QStringLiteral("\nDetalle: ") + detail + QStringLiteral("\n"));
        statusBar()->showMessage("Error al comunicarse con Ollama");
        reply->deleteLater();
        setWaitingState(false);
        return;
    }

    QJsonParseError parseError;
    const QJsonDocument doc = QJsonDocument::fromJson(rawData, &parseError);

    if (parseError.error != QJsonParseError::NoError || !doc.isObject()) {
        textEdit_->append(QStringLiteral("Error:\nLa respuesta de Ollama no es JSON válido."
                                      "\nDetalle: ") + parseError.errorString() + QStringLiteral("\n"));
        statusBar()->showMessage("Respuesta JSON inválida");
        reply->deleteLater();
        setWaitingState(false);
        return;
    }

    const QJsonObject obj = doc.object();

    if (obj.contains("error")) {
        textEdit_->append(QStringLiteral("Error Ollama:\n") + obj.value("error").toString() + QStringLiteral("\n"));
        statusBar()->showMessage("Ollama devolvió un error");
        reply->deleteLater();
        setWaitingState(false);
        return;
    }

    const QString response = obj.value("response").toString().trimmed();

    if (response.isEmpty()) {
        textEdit_->append(QStringLiteral("IA:\nLa respuesta llegó, pero no contiene texto en el campo 'response'.\n"));
    } else {
        textEdit_->append(QStringLiteral("IA:\n") + response + QStringLiteral("\n"));
    }

    statusBar()->showMessage("Respuesta recibida");
    reply->deleteLater();
    setWaitingState(false);
}

void MainWindow::setWaitingState(bool waiting)
{
    button_->setEnabled(!waiting);
    lineEdit_->setEnabled(!waiting);
    modelLineEdit_->setEnabled(!waiting);
    button_->setText(waiting ? "Esperando..." : "Enviar a Ollama");
}